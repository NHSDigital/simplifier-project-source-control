## {{page-title}}

@```
from StructureDefinition
select url
```

