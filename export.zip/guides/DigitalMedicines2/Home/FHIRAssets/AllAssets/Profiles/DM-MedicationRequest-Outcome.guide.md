## DM-MedicationRequest-Outcome

For reference only. This profile is used by EPS for `prescription-order-response` messages. 

{{tree:https://fhir.nhs.uk/StructureDefinition/NHSDigital-MedicationRequest-Outcome, snapshot}}