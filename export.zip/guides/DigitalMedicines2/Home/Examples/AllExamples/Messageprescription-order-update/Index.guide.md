### Message prescription-order-update

- {{pagelink:PrescriptionOrderHomecareUpdate-duplicate-2}} homecare order cancellation example.
- {{pagelink: PrescriptionOrderOutpatientCancel-duplicate-2}} 

<br />
