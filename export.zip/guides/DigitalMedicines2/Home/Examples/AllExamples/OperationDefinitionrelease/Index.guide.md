### OperationDefinition 

#### (prescription) $release

- {{pagelink:PatientPrescriptionReleaseRequest-duplicate-2}}
- {{pagelink:NominatedPharmacyReleaseRequest-duplicate-2}}
- {{pagelink:NominatedPharmacyReleaseRequest-unattended}}

<br />