## Downloads


| Current Release Package |  |
|--
| Package | uk.nhsdigital.medicines.r4 | 
| Version | 2.8.11 |
| IG Package Url | [https://simplifier.net/packages/uk.nhsdigital.medicines.r4.test/2.8.11-prerelease](https://simplifier.net/packages/uk.nhsdigital.medicines.r4.test/2.8.11-prerelease) |

