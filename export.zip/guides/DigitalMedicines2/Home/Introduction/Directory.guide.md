## {{page-title}}

<table class="regular" style="width:100%">
 <thead>
   <tr>
     <th >Stauts</th>
     <th >Version</th>
     <th >Date</th>
   </tr>
 </thead>
 <tbody>
 <tr>
    <td>Current</td>
    <td><a href="https://simplifier.net/guide/NHSDigital-medicines">2.8.11</td>
   <td>23 May 2023</td>
   </tr>
  <tr>
    <td>Past</td>
    <td><a href="https://simplifier.net/guide/digitalmedicines">2.1.14-alpha</td>
   <td>14 July 2021</td>
   </tr>
   </tbody>
</table>