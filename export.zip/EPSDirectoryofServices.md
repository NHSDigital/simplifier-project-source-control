#### {{page-title}}

[Electronic Prescription Service Directory of Services API](https://digital.nhs.uk/developer/api-catalogue/electronic-prescription-service-directory-of-services)

This API to access information about dispensing services, including searching for dispensers who can provide services for a patient with a given location and urgency.


