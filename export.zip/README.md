# FHIR Specification

 This repository is used in the [NHS Digital FHIR Medicines Implementation Guide](https://simplifier.net/guide/digitalmedicines/home) 

 [![NHSDigital IOPS Validation)](https://github.com/NHSDigital/NHSDigitial-FHIR-Medicines-ImplementationGuide/actions/workflows/terminology.yml/badge.svg)](https://github.com/NHSDigital/NHSDigitial-FHIR-Medicines-ImplementationGuide/actions/workflows/terminology.yml)
