## Profiles

This project is using the profiles shown below.

|Profiles| Maturity | 
|--
| {{pagelink:NHSDigital-Claim.md}} | 0 |
| [NHSDigital-CommunicationRequest](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-CommunicationRequest.guide.md) | 0 | 
| [NHSDigital-HealthcareService](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-HealthcareService.guide.md) | 0 | 
| {{pagelink:UKCore-List.md}} |0 |
| {{pagelink:NHSDigital-MedicationDispense}} | 0 | 
| {{pagelink:NHSDigital-MedicationRequest.md}} | 0 |
| {{pagelink:DM-MedicationRequest-Outcome.md}} | 0 |
| [NHSDigital-MessageHeader](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-MessageHeader.guide.md) |0 | 
| [NHSDigital-Organization](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-Organization.guide.md) |0 | 
| [NHSDigital-Patient](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-Patient.guide.md) |0 |
| [NHSDigital-Provenance](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-Provenance.guide.md) |0 | 
| [NHSDigital-Practitioner](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-Practitioner.guide.md) |0 | 
| [NHSDigital-PractitionerRole](https://simplifier.net/guide/NHSDigital/Home/FHIRAssets/AllAssets/Profiles/NHSDigital-PractitionerRole.guide.md)| 0 | 
| {{pagelink:NHSDigital-Task.md}} | 0 |

