## DM-MedicationRequest-Outcome

For reference only. This profile is used by EPS for `prescription-order-response` messages. 

{{tree: NHSDigital-medicationrequest-outcome, snapshot}}