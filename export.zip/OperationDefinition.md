## OperationDefinition

|OperationDefinition|Description|
|--
|{{pagelink:prepare}} ||
|{{pagelink:process-message}}||
|{{pagelink:release-duplicate-2.md}} | Release a prescription (Task)| 