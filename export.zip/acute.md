### {{page-title}}

{{render:prescribing-acute}}

An `acute` prescription is generated following a consultation between a prescriber and a patient and is a “one-off” prescription. 

#### MedicationRequest and MedicationDispense Notes

{{render:erd-acute}}