#### {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> Work in progress. This page is for illustration of a concept</div>

### MedicationRequest

| FHIR Exchange | API | FHIR Resource Profile | 
|--
| FHIR RESTful  | GET /MedicationRequest? | {{pagelink:NHSDigital-MedicationRequest.md}} | 

#### Search Parameters

See [MedicationRequest - Search Parameters](https://simplifier.net/guide/DigitalMedicines/NHSDigital-MedicationRequest-duplicate-2#search)

### MedicationDispense

| FHIR Exchange | API | FHIR Resource Profile | 
|--
| FHIR RESTful  | GET /MedicationDispense? | {{pagelink:NHSDigital-MedicationDispense.md}} | 

#### Search Parameters

See [MedicationDispense - Search Parameters](https://simplifier.net/guide/DigitalMedicines/NHSDigital-MedicationDispense-duplicate-2#search)